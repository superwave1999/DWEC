import Validator from './Validator.js';

var form = document.getElementById('elForm');
var valid = new Validator(form);
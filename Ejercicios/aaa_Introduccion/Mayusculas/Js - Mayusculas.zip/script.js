document.getElementById("send").addEventListener("click", validate);
resultLetHTML=document.getElementById("result");
numero = document.getElementById("txtbx");

function validate() {

    var parImpar = numero.value;

    if (validateLength(parImpar)) {
        console.log(parImpar);

        var upp = parImpar.toUpperCase();
        console.log(upp);
        var low = parImpar.toLowerCase();
        console.log(low);
        if (parImpar == upp) {
            resultLetHTML.innerHTML = "Es mayusculas";
        } else if (parImpar == low) {
            resultLetHTML.innerHTML = "Es minusculas";
        } else {
            resultLetHTML.innerHTML = "Es una mezcla de caracteres";
        }

    }

}

function validateLength (input) {
    if (isNaN(input)) {
        return true;
    } else {
        return false;
    }
}